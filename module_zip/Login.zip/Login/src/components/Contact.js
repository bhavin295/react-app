import React, { Component } from 'react';

class Contact extends Component {

	render() {
		return (
			<div>
				<h4 className="font-color"> Contact Us </h4>
				<span> Name : ABC </span><br />
				<span> Number : 9874563210 </span><br />
				<span> Email : test@user.com </span><br />
			</div>
		)
	}
}

export default Contact;