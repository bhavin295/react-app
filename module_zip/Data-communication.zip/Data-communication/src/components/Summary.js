import React, { Component } from 'react';

class Summary extends Component {

	render() {

		return (
			<div>
				<h4 className="font-color"> Summary </h4>
				<span> Welcome to our page </span><br />
			</div>
		)
	}
}

export default Summary;